# Pasta de migrações do banco (Supabase)

Coloque aqui as mudanças NOVAS do banco (criar tabela, coluna, política RLS).
Cada arquivo segue o nome:

    AAAAMMDDHHMMSS_descricao.sql
    exemplo: 20261112160000_cria_tabela_ocorrencias.sql

Quando a integração GitHub do Supabase estiver ligada com "Deploy to production",
cada arquivo novo que chegar na branch main é aplicado no banco sozinho.

IMPORTANTE: antes de ligar essa opção, o histórico de migrações que já existe no
banco precisa estar nesta pasta. Se faltar algum, o deploy do banco falha.
Peça ao Claude para sincronizar o histórico antes.
