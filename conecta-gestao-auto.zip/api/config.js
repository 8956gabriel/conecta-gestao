// api/config.js
// Função da Vercel que entrega a configuração do Supabase para as páginas HTML.
// Os valores vêm das variáveis de ambiente que a integração Supabase ↔ Vercel
// preenche sozinha. Nada de chave colada no código.
//
// Uso nas páginas:  <script src="/api/config"></script>
// Depois disso, window.SUPABASE_CONFIG fica disponível.

module.exports = (req, res) => {
  const url =
    process.env.SUPABASE_URL ||
    process.env.NEXT_PUBLIC_SUPABASE_URL ||
    '';

  // Só a chave PÚBLICA (anon/publishable). Nunca a service_role.
  const anonKey =
    process.env.SUPABASE_ANON_KEY ||
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
    process.env.SUPABASE_PUBLISHABLE_KEY ||
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
    '';

  const schema = process.env.SUPABASE_SCHEMA || 'gestao360';

  const config = { url, anonKey, schema };

  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  // Cache curto: se a chave mudar, as páginas pegam a nova em poucos minutos.
  res.setHeader('Cache-Control', 'public, max-age=0, s-maxage=300');

  if (!url || !anonKey) {
    res.status(200).send(
      'console.error("[Conecta Gestão] Supabase não configurado na Vercel. ' +
        'Verifique a integração Supabase em Settings > Integrations.");' +
        'window.SUPABASE_CONFIG = null;'
    );
    return;
  }

  res.status(200).send('window.SUPABASE_CONFIG = ' + JSON.stringify(config) + ';');
};
