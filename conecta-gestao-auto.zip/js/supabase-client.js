// js/supabase-client.js
// Cria UM cliente Supabase para todas as páginas, usando a configuração
// que veio de /api/config. Depois disso, use  window.sb  em qualquer página.
//
// Ordem dos scripts no <head> de cada página HTML:
//   <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
//   <script src="/api/config"></script>
//   <script src="/js/supabase-client.js"></script>

(function () {
  var cfg = window.SUPABASE_CONFIG;

  if (!cfg || !cfg.url || !cfg.anonKey) {
    console.error('[Conecta Gestão] Configuração do Supabase não encontrada.');
    return;
  }
  if (!window.supabase || !window.supabase.createClient) {
    console.error('[Conecta Gestão] Biblioteca supabase-js não carregou antes deste arquivo.');
    return;
  }

  // Valores antigos continuam funcionando para o código que já existe.
  window.SUPABASE_URL = cfg.url;
  window.SUPABASE_ANON_KEY = cfg.anonKey;

  window.sb = window.supabase.createClient(cfg.url, cfg.anonKey, {
    db: { schema: cfg.schema || 'gestao360' },
    auth: { persistSession: true, autoRefreshToken: true }
  });
})();
